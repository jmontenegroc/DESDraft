//
//  ContentView.swift
//  DESApp
//
//  Created by Alumno on 31/08/23.
//

import SwiftUI

struct ContentView: View {
    @Binding var isLoggedIn: Bool
    
    var body: some View {
        if isLoggedIn{
            MainView()
        } else {
            LoginView(isLoggedIn: $isLoggedIn)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(isLoggedIn: Binding.constant(false))
    }
}

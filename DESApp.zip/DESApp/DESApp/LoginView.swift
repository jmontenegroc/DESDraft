//
//  LoginVIew.swift
//  DESApp
//
//  Created by Alumno on 31/08/23.
//

import SwiftUI

struct LoginView: View {
    @Binding var isLoggedIn: Bool
    var body: some View {
        ZStack{
            Image("background")
                .resizable()
                .edgesIgnoringSafeArea(.all)
            VStack{
                Image("title")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 350)
                    .padding(35)
                Button(){
                    isLoggedIn.toggle()
                } label: {
                    ZStack{
                        Rectangle()
                            .fill(Color.black)
                            .frame(width: 300, height: 45)
                            .cornerRadius(10)
                        HStack {
                            Image(systemName: "applelogo")
                                .foregroundColor(.white)
                            
                            Text("Login with Apple ID")
                                .font(.headline)
                            .foregroundColor(.white)}
                    }
                }

            }
            
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView(isLoggedIn: Binding.constant(false))
    }
}


//
//  DESAppApp.swift
//  DESApp
//
//  Created by Alumno on 31/08/23.
//

import SwiftUI

@main
struct DESAppApp: App {
    @AppStorage("isLoggedIn") var isLoggedIn: Bool = false
    var body: some Scene {
        WindowGroup {
            ContentView(isLoggedIn: $isLoggedIn)
        }
    }
}

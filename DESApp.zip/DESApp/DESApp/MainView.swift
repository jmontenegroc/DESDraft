//
//  MainView.swift
//  DESApp
//
//  Created by Alumno on 01/09/23.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        NavigationStack{
            ZStack{
                Image("backgroundMain")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                VStack{
                    HStack{
                        NavigationLink(destination: MainView()) {
                            Image("usuario")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 40)
                        }
                        NavigationLink(destination: MainView()) {
                            Image("title")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 60)
                        }.padding(.horizontal,100)
                        NavigationLink(destination: MainView()) {
                            Image("ajuste")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 40)
                        }
                    }
                    Divider()
                        .background(Color.accentColor)
                    Spacer()
                }
            }
        }.navigationBarBackButtonHidden(true)
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
